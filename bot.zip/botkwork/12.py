@router.message(F.text == "📝 Создать объявление")
async def create_advertisement_entry(message: Message, state: FSMContext):
    msg = await message.answer(
        "Выберите сервер для размещения объявления:",
        reply_markup=await get_servers_keyboard(page=0)
    )
    await state.update_data(server_message_id=msg.message_id)
    await state.set_state(UserStates.WAITING_FOR_SERVER)



@router.callback_query(F.data.startswith("server_"))
async def process_server_selection(callback: CallbackQuery, state: FSMContext):
    server_id = int(callback.data.split("_")[1])
    data = await state.get_data()

    # Удаляем сообщение с серверами
    if 'server_message_id' in data:
        try:
            await callback.message.bot.delete_message(chat_id=callback.message.chat.id, message_id=data['server_message_id'])
        except:
            pass  # Игнорируем ошибку, если сообщение уже удалено

    await state.update_data(server_id=server_id)

    msg = await callback.message.answer(
        "✍️ Отправьте текст объявления (и только *одно* фото после этого).\n\nЕсли хотите отменить — нажмите кнопку ниже.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ Отменить", callback_data="cancel")]]),
        parse_mode="Markdown"
    )
    await state.update_data(text_prompt_id=msg.message_id)
    await state.set_state(UserStates.WAITING_FOR_TEXT)


@router.message(UserStates.WAITING_FOR_TEXT)
async def process_text(message: Message, state: FSMContext):
    data = await state.get_data()

    if 'text_prompt_id' in data:
        try:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=data['text_prompt_id'])
        except:
            pass

    await state.update_data(text=message.text)

    msg = await message.answer(
        "Хотите ли вы добавить фото к объявлению?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📸 Добавить фото", callback_data="add_photo")],
            [InlineKeyboardButton(text="🚀 Отправить без фото", callback_data="no_photo")],
            [InlineKeyboardButton(text="❌ Отменить", callback_data="cancel")]
        ])
    )
    await state.update_data(photo_prompt_msg_id=msg.message_id)
    await state.set_state(UserStates.CONFIRM_PHOTO_OPTION)


@router.callback_query(F.data == "add_photo")
async def handle_add_photo(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    msg_id = data.get("photo_prompt_msg_id")
    if msg_id:
        try:
            await callback.bot.delete_message(chat_id=callback.message.chat.id, message_id=msg_id)
        except Exception as e:
            print("Ошибка при удалении сообщения:", e)

    await callback.message.answer("📸 Отправьте *фото* для объявления", parse_mode="Markdown")
    await state.set_state(UserStates.WAITING_FOR_PHOTO)

@router.callback_query(F.data == "no_photo")
async def handle_no_photo(callback: CallbackQuery, state: FSMContext):
    # Удаляем клавиатуру
    await callback.message.edit_reply_markup(reply_markup=None)

    data = await state.get_data()

    # Удаляем предыдущее сообщение с вопросом, если оно есть
    msg_id = data.get("photo_prompt_msg_id")
    if msg_id:
        try:
            await callback.bot.delete_message(chat_id=callback.message.chat.id, message_id=msg_id)
        except Exception as e:
            print("Ошибка при удалении сообщения:", e)

    if 'text' not in data or 'server_id' not in data:
        await callback.message.answer("❗ Что-то пошло не так. Начните заново командой /start.")
        await state.clear()
        return

    db = Database()
    try:
        ad_id = db.add_advertisement(
            user_id=callback.from_user.id,
            server_id=data['server_id'],
            text=data['text'],
            photo_id=None
        )

        # Получаем данные о сервере
        server = db.get_server(data['server_id'])
        print("DEBUG: Полученные данные о сервере:", server)

        if not server:
            await callback.message.answer("❗ Ошибка: не удалось найти сервер.")
            return

        server_name = server[1] if len(server) > 1 else "Неизвестный сервер"

        await callback.bot.send_message(
            chat_id=server[3],  # moderation_group_id
            text=f"Новое объявление #{ad_id}\n\n{data['text']}\n\nОтправлено на сервер: {server_name}",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve_{ad_id}"),
                    InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_{ad_id}")
                ]
            ])
        )

        msg = await callback.message.answer(
            "✅ Ваше объявление отправлено на модерацию!",
            reply_markup=get_main_menu(callback.from_user.id)
        )

        # Удаляем сообщение через 5 секунд
        await asyncio.sleep(5)
        try:
            await msg.delete()
        except Exception as e:
            print("Не удалось удалить сообщение:", e)
    finally:
        db.close()
        await state.clear()


@router.message(UserStates.WAITING_FOR_PHOTO, F.photo)
async def process_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    if 'text' not in data or 'server_id' not in data:
        await message.answer("❗ Что-то пошло не так. Начните заново командой /start.")
        await state.clear()
        return

    photo_id = message.photo[-1].file_id

    db = Database()
    try:
        ad_id = db.add_advertisement(
            user_id=message.from_user.id,
            server_id=data['server_id'],
            text=data['text'],
            photo_id=photo_id
        )

        # Получаем данные о сервере
        server = db.get_server(data['server_id'])

        # Логируем, что мы получаем от базы данных
        print("DEBUG: Полученные данные о сервере:", server)  # Здесь логируем данные

        if not server:
            await message.answer("❗ Ошибка: не удалось найти сервер.")
            return

        # Получаем имя сервера (предположительно server[1])
        server_name = server[1] if len(server) > 1 else "Неизвестный сервер"

        # Отправляем сообщение с указанием сервера
        await message.bot.send_photo(
            chat_id=server[3],  # Используем moderation_group_id как chat_id
            photo=photo_id,
            caption=f"Новое объявление #{ad_id}\n\n{data['text']}\n\nОтправлено на сервер: {server_name}",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve_{ad_id}"),
                InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_{ad_id}")
            ]])
        )

        await message.answer(f"✅ Ваше объявление отправлено на модерацию на сервер: {server_name}!",
                             reply_markup=get_main_menu(message.from_user.id))
    finally:
        db.close()
        await state.clear()
