from aiogram import Router, types
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram import F
import asyncio
from database.db import Database
import config

router = Router()

class UserStates(StatesGroup):
    WAITING_FOR_SERVER = State()
    WAITING_FOR_TEXT = State()
    WAITING_FOR_PHOTO = State()
    CONFIRM_PHOTO_OPTION = State()


def get_main_menu(user_id: int) -> ReplyKeyboardMarkup:
    base_buttons = [[KeyboardButton(text="📝 Создать объявление")]]

    # Проверяем, является ли пользователь администратором
    if Database.is_admin(user_id) or user_id in config.ADMIN_IDS:
        base_buttons.append([KeyboardButton(text="🛠 Админ-панель")])

    return ReplyKeyboardMarkup(
        keyboard=base_buttons,
        resize_keyboard=True
    )

@router.message(Command("start"))
async def start(message: Message, state: FSMContext):
    db = Database()
    db.add_user_if_not_exists(
        user_id=message.from_user.id,
        username=message.from_user.username,
        full_name=message.from_user.full_name
    )
    db.close()

    await state.clear()
    await message.answer(
        "👋 Добро пожаловать в *BLACK russia Б/У РЫНОК*\n\n"
        "🛍️ *SellVibe* — бот для быстрой подачи объявлений!\n\n"
        "✍️ Подавай объявление, лови хороший вайб! Нажми кнопку ниже ⬇️",
        reply_markup=get_main_menu(message.from_user.id),
        parse_mode="Markdown"
    )
async def get_servers_keyboard(page: int = 0) -> InlineKeyboardMarkup:
    db = Database()
    servers = db.get_servers()
    db.close()

    servers_per_page = 20
    start = page * servers_per_page
    end = start + servers_per_page
    current_servers = servers[start:end]

    # Разбиваем на две равные части (если возможно)
    half = (len(current_servers) + 1) // 2
    left_column = current_servers[:half]
    right_column = current_servers[half:]

    rows = []
    for i in range(max(len(left_column), len(right_column))):
        row = []
        if i < len(left_column):
            row.append(InlineKeyboardButton(
                text=left_column[i][1],
                callback_data=f"server_{left_column[i][0]}"
            ))
        if i < len(right_column):
            row.append(InlineKeyboardButton(
                text=right_column[i][1],
                callback_data=f"server_{right_column[i][0]}"
            ))
        rows.append(row)

    # Кнопки пагинации
    pagination_buttons = []
    if page > 0:
        pagination_buttons.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"page_{page - 1}"))
    if end < len(servers):
        pagination_buttons.append(InlineKeyboardButton(text="Вперёд ▶️", callback_data=f"page_{page + 1}"))

    if pagination_buttons:
        rows.append(pagination_buttons)

    return InlineKeyboardMarkup(inline_keyboard=rows)

@router.message(F.text == "📝 Создать объявление")
async def create_advertisement_entry(message: Message, state: FSMContext):
    msg = await message.answer(
        "Выберите сервер для размещения объявления:",
        reply_markup=await get_servers_keyboard(page=0)
    )
    await state.update_data(server_message_id=msg.message_id)
    await state.set_state(UserStates.WAITING_FOR_SERVER)


@router.callback_query(F.data.startswith("server_"))
async def process_server_selection(callback: CallbackQuery, state: FSMContext):
    server_id = int(callback.data.split("_")[1])
    data = await state.get_data()

    if 'server_message_id' in data:
        try:
            await callback.message.bot.delete_message(chat_id=callback.message.chat.id, message_id=data['server_message_id'])
        except:
            pass

    await state.update_data(server_id=server_id)

    msg = await callback.message.answer(
        "✍️ Отправьте *текст* объявления. Вы можете прикрепить к нему *одно фото* (вместе с подписью) или отправить только текст.\n\nЕсли хотите отменить — нажмите кнопку ниже.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ Отменить", callback_data="cancel")]]),
        parse_mode="Markdown"
    )
    await state.update_data(text_prompt_id=msg.message_id)
    await state.set_state(UserStates.WAITING_FOR_TEXT)


@router.message(UserStates.WAITING_FOR_TEXT)
async def process_text_or_photo(message: Message, state: FSMContext):
    data = await state.get_data()

    if 'text_prompt_id' in data:
        try:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=data['text_prompt_id'])
        except:
            pass

    text = message.text or message.caption
    photo = message.photo[-1].file_id if message.photo else None

    if not text:
        await message.answer("❗ Пожалуйста, отправьте текст или фото с подписью.")
        return

    if 'server_id' not in data:
        await message.answer("❗ Что-то пошло не так. Начните заново командой /start.")
        await state.clear()
        return

    db = Database()
    try:
        server = db.get_server(data['server_id'])
        if not server:
            await message.answer("❗ Ошибка: не удалось найти сервер.")
            return

        server_name = server[1] if len(server) > 1 else "Неизвестный сервер"

        await state.update_data(text=text, photo_id=photo, server_name=server_name)

        preview_text = f"📢 *Предпросмотр объявления:*\n\n{text}\n\n📍 *Сервер:* {server_name}"

        if photo:
            await message.answer_photo(
                photo=photo,
                caption=preview_text,
                parse_mode="Markdown"
            )
        else:
            await message.answer(preview_text, parse_mode="Markdown")

        await message.answer(
            "Отправить объявление на модерацию?",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🚀 Отправить", callback_data="confirm_send")],
                [InlineKeyboardButton(text="❌ Отменить", callback_data="cancel")]
            ])
        )
        await state.set_state(UserStates.CONFIRM_SEND)

    finally:
        db.close()

@router.callback_query(F.data == "confirm_send")
async def confirm_send(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()

    if not all(k in data for k in ('text', 'server_id', 'server_name')):
        await callback.message.answer("❗ Ошибка: недостаточно данных. Попробуйте сначала.")
        await state.clear()
        return

    db = Database()
    try:
        ad_id = db.add_advertisement(
            user_id=callback.from_user.id,
            server_id=data['server_id'],
            text=data['text'],
            photo_id=data.get('photo_id')
        )

        moderation_chat_id = db.get_server(data['server_id'])[3]

        if data.get('photo_id'):
            await callback.bot.send_photo(
                chat_id=moderation_chat_id,
                photo=data['photo_id'],
                caption=f"Новое объявление #{ad_id}\n\n{data['text']}\n\nОтправлено на сервер: {data['server_name']}",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [
                        InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve_{ad_id}"),
                        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_{ad_id}")
                    ]
                ])
            )
        else:
            await callback.bot.send_message(
                chat_id=moderation_chat_id,
                text=f"Новое объявление #{ad_id}\n\n{data['text']}\n\nОтправлено на сервер: {data['server_name']}",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [
                        InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve_{ad_id}"),
                        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_{ad_id}")
                    ]
                ])
            )

        msg = await callback.message.answer(
            "✅ Объявление отправлено на модерацию!",
            reply_markup=get_main_menu(callback.from_user.id)
        )
        await asyncio.sleep(5)
        try:
            await msg.delete()
        except:
            pass
        await callback.message.answer(
            reply_markup=get_main_menu(callback.from_user.id)
        )
    finally:
        db.close()
        await state.clear()

@router.callback_query(F.data.startswith("page_"))
async def handle_page_navigation(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    await callback.message.edit_text(
        "Выберите сервер для размещения объявления:",
        reply_markup=await get_servers_keyboard(page)
    )



@router.callback_query(F.data == "cancel")
async def cancel_advertisement(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("❌ Создание объявления отменено")


@router.callback_query(F.data.startswith("approve_"))
async def approve_advertisement(callback: CallbackQuery):
    ad_id = int(callback.data.split("_")[1])
    db = Database()
    try:
        ad = db.get_advertisement(ad_id)
        if ad:
            server = db.get_server(ad[2])
            channel_id = server[2]

            photo_id = ad[4]
            caption = ad[3]

            if photo_id:
                message = await callback.bot.send_photo(
                    chat_id=channel_id,
                    photo=photo_id,
                    caption=caption
                )
            else:
                message = await callback.bot.send_message(
                    chat_id=channel_id,
                    text=caption
                )

            db.update_advertisement_status(ad_id, "approved")

            await callback.bot.send_message(
                chat_id=ad[1],
                text="✅ Ваше объявление было *одобрено* и опубликовано!",
                parse_mode="Markdown"
            )

            await callback.message.answer("Объявление одобрено и опубликовано ✅")

            # Удаляем сообщение через 2 минуты (120 секунд)
            await asyncio.sleep(120)
            try:
                await callback.bot.delete_message(chat_id=callback.message.chat.id,
                                                  message_id=callback.message.message_id)
            except Exception as e:
                print(f"Не удалось удалить сообщение: {e}")

            # Удаляем сообщение с подтверждением
            await message.delete()

    finally:
        db.close()


@router.callback_query(F.data.startswith("reject_"))
async def reject_advertisement(callback: CallbackQuery):
    ad_id = int(callback.data.split("_")[1])
    db = Database()
    try:
        ad = db.get_advertisement(ad_id)
        if ad:
            db.update_advertisement_status(ad_id, "rejected")

            await callback.bot.send_message(
                chat_id=ad[1],
                text="❌ Ваше объявление было *отклонено* модератором.",
                parse_mode="Markdown"
            )

            await callback.message.edit_text("Объявление отклонено")

            # Удаляем сообщение через 2 минуты (120 секунд)
            await asyncio.sleep(120)
            try:
                await callback.bot.delete_message(chat_id=callback.message.chat.id,
                                                  message_id=callback.message.message_id)
            except Exception as e:
                print(f"Не удалось удалить сообщение: {e}")

    finally:
        db.close()
